# Final Project for ISCI-418Y, Software Engineering, Spring 2019

### [Group Chat Invite Link](https://join.slack.com/t/icsi-418team/shared_invite/enQtNTU4NjUxODQ4NTQ2LTM2MDMwY2ExM2U0YjU0ZjMzNzkzY2JlNGFiMTQ4YWJlMjBkM2JmNTMyZThlMWRkZmYxZjhhZTcxYWQ5M2E5Y2I)
* [Slack](https://www.slack.com) Team Code: __icsi-418team__.slack.com

### [Wire-Frame Invite Link](https://drive.google.com/file/d/1x-5YBpBQQn3sGen98tNRY536cOMy9JH7/view?usp=sharing)
* A [draw.io](https://www.draw.io) diagram hosted on Google Drive

### [Entity Relationship Diagram Invite Link](https://drive.google.com/file/d/1XlezssqVcUBls8oMyGCVEdJGmtN95HkN/view?usp=sharing)
* A [draw.io](https://www.draw.io) diagram hosted on Google Drive

### [Trello Invite Link](https://trello.com/invite/b/pfH92DPN/355ce0c1f77e07fc7a083b350d3e0692/icsi-418-group-project)
* A repository/task manager for hosting our product backlog and sprints

### [Assignment PDF](https://github.com/lprescott/ICSI418-Group-Project/blob/master/project-logistics/Final%20Project%20for%20CSI%20418%20Spring%202019.pdf)
  
### Team Members:
1. Luke R. Prescott
2. Sean Loucks
3. Jack Holden
4. Max Moore
5. Chin Wa Cheung
6. Will Dahl
7. Gary Passarelli
    
### Comma Seperated list for Quizzes:
Luke Prescott, Sean Loucks, Jack Holden, Max Moore, Chin Wa Cheung, Will Dahl, Gary Passarelli
